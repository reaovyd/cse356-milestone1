# Example CRDT Wrapper Library

This project is a template for you to get up and started with writing your own CRDT wrapper library. The entry point is `src/index.ts`. There, you'll find a couple of  functions for you to implement - you must NOT change these function names.

You are free to modify this library however else you'd like to get your solution to work.

## Setup
Run `npm install` to install all dependencies.

## Basic Usage
1. Run `npm run build` to create a distribution bundle.
2. If the build command succeeds, your bundle should now be available in `dist/`. You should make this minified bundle publicly available at `<YOUR_URL>/library/crdt.js`.